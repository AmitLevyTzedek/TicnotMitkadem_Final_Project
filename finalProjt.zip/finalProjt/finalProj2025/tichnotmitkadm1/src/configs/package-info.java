/**
 * This package is responsible for loading configuration files
 * and initializing the necessary parameters for the website.
 */
package configs;

/**
 * This package implements the HTTP server component,
 * which is responsible for forwarding incoming requests to the appropriate servlet.
 */
package server;

/**
 * This package contains the servlets that handle HTTP GET and POST requests,
 * and respond accordingly to client actions.
 */
package servlets;
